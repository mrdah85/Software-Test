package TaskService;

import java.awt.Taskbar;
import java.util.ArrayList;

public class TaskService {
	//create array list of task
	public static ArrayList<Taskbar>tasks = new ArrayList<>();
	
	//create method to add task
	@SuppressWarnings("unused")
	public static <Task> boolean addTask (Taskbar task) {
		boolean exists = false;
		
		for (Taskbar taskList : tasks) {
			if(Taskbar.getTaskbar().equals(Taskbar.getTaskbar())) {
				exists = true;
			}
		}
		if(!exists) {
			tasks.add(task);
		}
		return exists;
	}
	
	//create method to delete task
	@SuppressWarnings("unused")
	public static boolean deleteTask(Taskbar task) 
		{boolean deleted = false;
		for(Taskbar taskList : tasks) {
			
		}
		return deleted;
	}
}

