package appointmentTest;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.util.Calendar;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

import appointment.appointment;
import appointmentServiceTest.appointmentServiceTest;

public class appointmentTest {
	 private String id, description;
	 private String tooLongId, tooLongDescription;
	 private Date date, pastDate;
	 @SuppressWarnings("deprecation")
	 
	 @Before
	 void setUp() {
	 id = "1234567890";
	 description = "The appt object shall have a required description.";
	 date = new Date(3021, Calendar.JANUARY, 1);
	 tooLongId = "111222333444555666777888999";
	 tooLongDescription =
	 "This description is too long for the appointment requirements but good for testing.";
	 pastDate = new Date(0);
			
	 }
	 
	 @Test
	 void testUpdateAppointmentId() {
	 appointment appt = new appointment();
	 assertThrows(IllegalArgumentException.class,
	 () -> appt.updateAppointmentID(null));
	 assertThrows(IllegalArgumentException.class,
	 () -> appt.updateAppointmentID(tooLongId));
	 appt.updateAppointmentID(id);
	 assertEquals(id, appt.getAppointmentId());
	 
	 }
	 
	 @Test
	 void testGetAppointmentId() {
	 appointment appt = new appointment();
	 assertNotNull(appt.getAppointmentId());
	 assertEquals(appt.getAppointmentId().length(), 10);
	 assertEquals(id, appt.getAppointmentId());
	 
	 }
	 
	 @Test
	 void testUpdateDate() {
	 appointment appt = new appointment();
	 assertThrows(IllegalArgumentException.class, () -> appt.updateDate(null));
	 assertThrows(IllegalArgumentException.class,
	 () -> appt.updateDate(pastDate));
	 appt.updateDate(date);
	 assertEquals(date, appt.getAppointmentDate());
	 
	 }
	 
	 @Test
	 void testGetAppointmentDate() {
	 appointment appt = new appointment();
	 assertNotNull(appt.getAppointmentDate());
	 assertEquals(date, appt.getAppointmentDate());
	 
	 }
	 
	 @Test
	 void testUpdateDescription() {
	 appointment appt = new appointment();
	 assertThrows(IllegalArgumentException.class,
	 () -> appt.updateDescription(null));
	 assertThrows(IllegalArgumentException.class,
	 () -> appt.updateDescription(tooLongDescription));
	 appt.updateDescription(description);
	 assertEquals(description, appt.getDescription());
	 
	 }
	 
	 @Test
	 void testGetDescription() {
	 appointment appt = new appointment();
	 assertNotNull(appt.getDescription());
	 assertTrue(appt.getDescription().length() <= 50);
	 assertEquals(description, appt.getDescription());
	 }

	public void deleteAppointment() {
		// TODO Auto-generated method stub
		
	}

	public Calendar getAppointmentList() {
		// TODO Auto-generated method stub
		return null;
	}

}
