package contactTest;

import org.junit.Test;

import contact.java.contact;

public class contactTest<Contact> {
	contact contact = new contact("member # 1", "firstName", "lastName", "123.456.789", "123 Lake St"); 
    // making the object as a class member so that all the methods can access it

    @Test
    void getContactID() {
        assertEquals("member #1", contact.getContactID());
    }

    private void assertEquals(String string, String contactID) {
		// TODO Auto-generated method stub
		
	}

	@Test
    void getFirstName() {
        assertEquals("firstName", ((contact) contact.java).getFirstName());
    }

    @Test
    void getLastName() {
        assertEquals("lastName", contact.getLastName());
    }

    @Test
    void getPhoneNumber() {
        assertEquals("123.456.789", contact.getPhoneNumber());
    }

    @Test
    void getAddress() {
        assertEquals("123 Lake St", contact.getAddress());
    }

    @Test
    void testToString() {
        assertEquals("Contact [contactID=member #1, firstName=firstName, lastName=lastName, phoneNumber=123.456.789, address = 123 Lake St]");
    }

	private void assertEquals(String string) {
		// TODO Auto-generated method stub
		
	}

}

