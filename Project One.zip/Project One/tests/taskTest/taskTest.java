package taskTest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import Task.java.Task;

public class taskTest {

	private String id, name, description;
	private String tooLongId, tooLongName, tooLongDescription;
	
	@Before
	void setUp() {id = "1234567890";
	name = "This is Twenty Chars";
	description = "The task object shall have a required description.";
	tooLongId = "111222333444555666777888999";
	tooLongName = "This is way too long to be a task name";
	tooLongDescription ="The task object shall have a required description String field thatcannot be longer than 50 characters. The description field shall not be null.";
	
	}
	
	@Test
	void getTaskIdTest1() {
		Task task = new Task();
		Assert.assertEquals(id, task.getId());
			
	}
	
	@Test
	void setNameTest() {
		taskTest task = new taskTest();
		task.setName(name);
		Assert.assertEquals(name, task.getName());
		
	}
	
	@Test
	void setDescriptionTest() {
		taskTest task = new taskTest();
		task.setDescription(description);
		
	}
	
	public void setDescription(String description2) {
		// TODO Auto-generated method stub
		
	}

	@Test
	void setTooLongNameTest() {
		Task task = new Task();Assert.assertThrows(IllegalArgumentException.class,
				() -> task.setName(tooLongName));
		
	}
	
	@Test
	void setTooLongDescriptionTest() {
		Task task = new Task();
		Assert.assertThrows(IllegalArgumentException.class,
				() -> task.setDescription(tooLongDescription));
		
	}
	
	@Test
	void TaskNameNullTest() {
		Task task = new Task();
		Assert.assertThrows(IllegalArgumentException.class,
				() -> task.setName(null));
		
	}
	
	@Test
	void TaskDescriptionNullTest() {
		Task task = new Task();
		Assert.assertThrows(IllegalArgumentException.class,
				() -> task.setDescription(null));
	}

	public void setName(String name2) {
		// TODO Auto-generated method stub
		
	}

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getId() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setName1(String name2) {
		// TODO Auto-generated method stub
		
	}
	
}
