package taskServiceTest;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.junit.Test;

import Task.java.Task;
import taskTest.taskTest;

public class taskServiceTest {
	public static List<taskTest> tasks = new ArrayList<>();

	   @Test 
	   public void validTaskData() {
	      Task task = new Task();
	      addTask(task);
	      System.out.println("New Task: " + tasks);
	      System.out.println("size: " + tasks.size());
	   }
	   
	   @Test 
	   public void invalidID() {      
	      Task task = new Task();
	      addTask(task);
	      System.out.println("size: " + tasks.size());
	   }
	   
	   @Test 
	   public void updateTask() {      
	      Task task = new Task();
	      update(task);
	      System.out.println("Updated: " + tasks);
	      System.out.println("size: " + tasks.size());
	   }
	   
	   @Test 
	   public void deleteTask() {
	      deleteTask("001");
	      System.out.println("size: " + tasks.size());
	   }   
	   
	   public boolean addTask(Task task) {
	        //use Collections binary search to check if the ID already exists
	        //if task ID is not found, return negative values
	        int index = getIndex(task);

	        //validate id if doesn't exist, name & description
	        if (index < 0 && validateID(task.getId()) && validateName(task.getName()) && validateDescription(task.getDescription())) {
	            
	            return true;
	        }
	        
	        return false;
	    }
	    
	    /**
	     *
	     * @param id
	     *
	     * delete Task object when Task ID exist
	     *
	     */
	    public void deleteTask(String id) {
	        //invoke getIndex(Task) method
	        //create new instance of Task object and pass the String ID in the constructor, set name and description as empty or null
	        //if ID found, return in value as List index (0...N)
	        int index = getIndex(new Task());
	        
	        //check if index is greater than or equal to 0 to prevent ArrayIndexOutOfBoundsException
	        if (index >= 0)
	            tasks.remove(index);
	    }

	    /**
	     *
	     * @param task
	     * 
	     * update Task object if same ID and valid name and description
	     */
	    public void update(Task task) {
	        for (taskTest obj : tasks) {
	            if (obj.equals(task) && validateName(task.getName()) && validateDescription(task.getDescription())) {
	               
	            }
	        }
	    }
	    
	    /**
	     *
	     * @param task
	     * @return integer data type
	     * 
	     * use Collections binary search by Task ID
	     * return positive integer from 0 to N if ID is found
	     * return negative integer if ID is not found
	     */
	    public int getIndex(Task task) {
	        int index = Collections(tasks, task, Task.compareById);
	        return index;
	    }

	    private int Collections(List<taskTest> tasks2, Task task, Comparator<Task> compareById) {
			// TODO Auto-generated method stub
			return 0;
		}

		/**
	     * 
	     * @param id
	     * @return true or false
	     * 
	     * validate id parameter, if not null and length is less than or equal to 10
	     */
	    public boolean validateID(String id) {
	        if (id != null && id.length() <= 10)
	            return true;

	        return false;
	    }

	    /**
	     * 
	     * @param name
	     * @return true or false
	     * 
	     * validate name parameter, if not null and length is less than or equal to 20
	     */
	    public boolean validateName(String name) {
	        if (name != null && name.length() <= 20)
	            return true;

	        return false;
	    }

	    /**
	     * 
	     * @param object
	     * @return true or false
	     * 
	     * validate description parameter, if not null and length is less than or equal to 50
	     */
	    public boolean validateDescription(Object object) {
	        if (object != null && ((String) object).length() <= 50)
	            return true;

	        return false;
	    }

	}


	


