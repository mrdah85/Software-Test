package contactServiceTest;

public class contactServiceTest {

	// Test the add methods.

	//Test

	public void testAdd(){

	ContactService cs = new ContactService();

	Contact t1 = new Contact("1", "David", "Hairston", "3100", "Meadowood St");

	assertEquals(true, cs.addContact(t1));

	}

	private void assertEquals(boolean b, Object addContact) {
		// TODO Auto-generated method stub
		
	}

}

