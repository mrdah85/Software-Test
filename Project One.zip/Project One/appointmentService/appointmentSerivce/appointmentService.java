package appointmentSerivce;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class appointmentService {
	final private List<appointmentService> appointmentList = new ArrayList<>();
	
	public void newAppointment() {
		appointmentService appt = new appointmentService();
		appointmentList.add(appt);
		
	}
	
	public void newAppointment(Date date) {appointmentService appt = new appointmentService();
	appointmentList.add(appt);}public void newAppointment(Date date, String description) 
	{@SuppressWarnings("unused")
	appointmentService appt = new appointmentService();
	
	}

	public Calendar getAppointmentList() {
		// TODO Auto-generated method stub
		return null;
	}
}
