package contactService;

import java.awt.Container;
import java.util.ArrayList;

public class contactService {

	ArrayList <contactService> contacts;

	public boolean addContact(contactService t1) {
		boolean contains = false;
		for (contactService c : contacts) 
	{
			if (c.getContactID().equalsIgnoreCase(t1.getContactID())) {
				contains = true;
				break;
			}
		}
		
		if (!contains) {
			contacts.add(t1);
			return true;
		} else 
		{
			return false;
		}
	}

	private String getContactID() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object addContact(Container t1) {
		// TODO Auto-generated method stub
		return null;
	}
}

