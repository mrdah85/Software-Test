package contact.java;

public class contact {
	private static String contactID;
	public static Object java;
	private static String firstName;
	private static String lastName;
	private static String phoneNumber;
	private static String address;
	
	public contact(String contactId,String firstName,String lastName ,String phone,String address) {
		if(contactId.length() <= 10 && contactId != null) {
			this.contactID = contactId;
		}
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setPhoneNumber(phone);
		this.setAddress(address);
	}

	public void setFirstName(String firstName) {
		if(firstName.length() <= 10 && firstName != null) {
			this.firstName = firstName;
		}
	}
	
	public void setLastName(String lastName) {
		if(lastName.length() <= 10 && lastName != null) {
			this.lastName = lastName;
		}
	}

	public void setPhoneNumber(String phoneNumber) {
		if(phoneNumber.length() == 10 && phoneNumber != null) {
			this.phoneNumber = phoneNumber;
		}
	}
	
	public void setAddress(String address) {
		if(address.length() <= 30 && address != null) {
			this.address = address;
		}
	}

	public static String getContactID() {
		return contactID;
	}

	public String getFirstName() {
		return firstName;
	}

	public static String getLastName() {
		return lastName;
	}

	public static String getPhoneNumber() {
		return phoneNumber;
	}

	public static String getAddress() {
		return address;
	}

	public String toString() {
		return "Contact [contactID=" + contactID + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", phoneNumber=" + phoneNumber + ", address=" + address + "]";
	}
}

